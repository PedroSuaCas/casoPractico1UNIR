import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='pedrosuarcast',
    application_name='todo-list-serverless',
    app_uid='cfFw8kDM7HDzczg300',
    org_uid='f1cadfb9-fab5-483c-9317-920ed8419bea',
    deployment_uid='48b54dff-f885-4e8e-b232-73867be7fad4',
    service_name='api-rest-v1',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.2.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'api-rest-v1-dev-list', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/list.list')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
