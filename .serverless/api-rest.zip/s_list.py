import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='pedrosuacas',
    application_name='todo-list-serverless',
    app_uid='0jCddxc2SlMXwdRKCH',
    org_uid='17cc30c7-c971-484e-aa30-073c3f0b4ecb',
    deployment_uid='f8506b51-afbb-49f8-bf33-cc0a4ea56726',
    service_name='api-rest',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.0.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'api-rest-dev-list', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/list.list')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
